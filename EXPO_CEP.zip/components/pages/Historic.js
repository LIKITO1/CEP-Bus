import {View,Text,Pressable} from "react-native"
import Menu from "../layouts/Menu"
import {styles} from "../styles/historicStyles"
import { SafeAreaView } from "react-native-safe-area-context"
import {useState,useEffect} from "react"
import AsyncStorage from "@react-native-async-storage/async-storage"
export default function Historic(){
    const [historico,setHistorico]=useState([])
    async function verHistorico(){
        const data=await AsyncStorage.getItem("historico")
        if(data){
            setHistorico(JSON.parse(data))
        }else{
            setHistorico([])
        }
    }
    useEffect(()=>{
        (async function(){
            await verHistorico()
        })()
    },[])
    function mostrar(e){
        console.log(e)
    }
    return(
        <SafeAreaView style={{flex:1}}>
        <View style={styles.container}>
            <View style={styles.top}>
                <Text style={styles.title}>Histórico</Text>
                {historico.length>0&&(
                    <Pressable style={styles.clearBtn}>
                        <Text style={styles.textClear}>Limpar Histórico</Text>
                    </Pressable>
                )}
            </View>
            <View style={styles.itens}>
                    {historico.length === 0&&(
                        <View>
                            <Text style={styles.empty}>O histórico está vazio</Text>
                            <Text style={styles.subtext}>Nenhuma busca foi realizada</Text>
                        </View>
                    )}
                    {historico.map((valor)=>(
                        <Pressable style={styles.item} key={valor} onPress={()=>mostrar(valor)}>
                            <Text style={styles.textItem}>CEP: {valor}</Text>
                        </Pressable>
                    ))}
                </View>
            <Menu/>
        </View>
        </SafeAreaView>
    )
}
